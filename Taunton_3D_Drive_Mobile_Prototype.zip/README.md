# Taunton 3D Drive prototype

## What it does
- Loads Google's Photorealistic 3D Tiles around Taunton.
- Starts near central Taunton.
- Adds a simple drivable vehicle/camera.
- Mobile touch controls + keyboard controls.
- Chase/driver camera toggle and reset.
- Google tile attribution is shown on-screen.

## Run it
1. Create a Google Maps Platform project with billing enabled.
2. Enable the Map Tiles API / Photorealistic 3D Tiles.
3. Create an API key and restrict it to the website origin when deploying.
4. Serve this folder from a local web server (for example `python -m http.server`) rather than opening the HTML directly as a file.
5. Open `index.html` in a mobile/desktop browser and paste the key.

## Important
This is a prototype. It streams Google's tiles rather than downloading Google's map database. The vehicle currently moves freely over the 3D scene; it does not yet follow the road network or perform collision detection against buildings.

Google Photorealistic 3D Tiles require appropriate Google Maps Platform credentials and attribution.
